# AIL Reference Compiler — TypeScript

**Status:** stub. Implement `packages/`-style modules against the frozen fixtures in
`../../tests/golden/`. Suggested first module boundary: `lexer/` emitting the token
contract in `tokens.json`. See [`../README.md`](../README.md) for the pass map.
